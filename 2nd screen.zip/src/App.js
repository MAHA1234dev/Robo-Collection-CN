import './App.css';
import DigitalCollectionExecutiopnDetails from './components/DigitalCollectionExecutiopnDetails';

function App() {
  return (
    <div className="App">
      <DigitalCollectionExecutiopnDetails/>
    </div>
  );
}

export default App;
