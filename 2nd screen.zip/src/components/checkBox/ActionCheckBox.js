import { Checkbox } from '@material-ui/core'
import { pink } from '@material-ui/core/colors'
import React from 'react'
export default function ActioncheckBox() {
    return (
        // <div className="form-check">
        //     <input className="form-check-input" type="checkbox" value="" id="flexCheckChecked" checked/>
        //         <label className="form-check-label" for="flexCheckChecked">
        //             Checked checkbox
        //         </label>
        // </div>
        // import { pink } from '@mui/material/colors';
        // import Checkbox from '@mui/material/Checkbox';

        // const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

        <div>

            <Checkbox defaultChecked color="white" />
            <Checkbox
                // {...label}
                defaultChecked
                sx={{
                    // color: "white",
                    // '&.Mui-checked': {
                    //     color: "white",
                    // },
                    color:"primary"
                }}
            />
        </div>

    )
}